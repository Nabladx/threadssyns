#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>

#define COUNT_TO  4
#define MAX_CORES 12

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
long long i = 0;

void *start_counting(void *arg) {
    for (;;) {
        // acquire lock
        pthread_mutex_lock(&mutex);
        // check if all COUNT_TO has been arrived at
	if (i >= COUNT_TO) {
            pthread_mutex_unlock(&mutex);
            return NULL;
        }
	srand(time(NULL));
	double *ps = (double*) malloc(sizeof(double));
	double *ds = (double*) malloc(sizeof(double));
	double a[] = { 1.0, 2.0, 3.0, 4.0 };
	double ar[] = { 1.0, 4.0, 9.0, 16.0 };
	double arr[4];
	double m = 0.0, d = 0.0, m_in_2 = 0.0, m_2_in = 0.0;
	for (int j = 0;j < 4;j++)
	{
		scanf("%lf", &arr[j]);
	}
	for (int j = 0;j < 4;j++)
	{
		m = m + a[j] * arr[j];
	}
	m_2_in = m * m;
	for (int j = 0;j < 4;j++)
	{
		m_in_2 = m_in_2 + ar[j] * arr[j];
	}
	d = m_in_2 - m_2_in;
        ++i;
        // release lock
        pthread_mutex_unlock(&mutex);
        printf("m = %f\n", m);
	printf("d = %f\n", d);
    }
}

int main(void) {
    int i = 0;
    // create a thread group the size of MAX_CORES
    pthread_t *thread_group = malloc(sizeof(pthread_t) * MAX_CORES);
    // start all threads to begin work
    for (i = 0; i < MAX_CORES; ++i) {
        pthread_create(&thread_group[i], NULL, start_counting, NULL);
    }
    // wait for all threads to finish
    for (i = 0; i < MAX_CORES; ++i) {
        pthread_join(thread_group[i], NULL);
    }
    return EXIT_SUCCESS;
}
